# -*- coding: utf-8 -*-
"""
Created on Wed Jul  5 20:51:05 2023

@author: Dell
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#pip install python-docx 
#gensim==3.8.2
#pip install rake-nltk
import docx
import re
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import pandas as pd

from keybert import KeyBERT

kw_model = KeyBERT(model='paraphrase-multilingual-mpnet-base-v2')

#kw_model = KeyBERT(model='all-mpnet-base-v2')

#kw_model = KeyBERT(model='all-mpnet-base-v2')

texto = []
nuevo = []
lista = [' ',".",",",":",";"]
df = pd.DataFrame()

document = docx.Document('LucaTraverso_CV.docx')

stop_words = set(stopwords.words('spanish'))

def read_document(document):
    texto = []
    palabra = ''
    
    for parrafo in document.paragraphs:
        for letras in parrafo.text:
            if letras not in lista:
                palabra = palabra+letras
            else:
                texto.append(palabra)
                palabra=''
    
    return " ".join(texto)

###### Preprocessing
def pre_process(text):
    
    # lowercase
    text=text.lower()
    
    #remove tags
    text=re.sub("&lt;/?.*?&gt;"," &lt;&gt; ",text)
    
    # remove special characters and digits
    text=re.sub("(\\d|\\W)+"," ",text)
    
    ##Convert to list from string
    text = text.split()
    
    # remove stopwords
    text = [word for word in text if word not in stop_words]

    # remove words less than three letters
    text = [word for word in text if len(word) >= 3]

    # lemmatize
    lmtzr = WordNetLemmatizer()
    text = [lmtzr.lemmatize(word) for word in text]
    
    return ' '.join(text)



#### Cargar documento
text_read = read_document(document)

#### Preprocesamiento
text_preprocessing = pre_process(text_read)

keywords = kw_model.extract_keywords(text_preprocessing, 

                                     keyphrase_ngram_range=(1, 2), 

                                     stop_words='english', 

                                     highlight=True,

                                     top_n=10)

keywords_list= list(dict(keywords).keys())

print(keywords_list)

#print(keywords(text_preprocessing))

