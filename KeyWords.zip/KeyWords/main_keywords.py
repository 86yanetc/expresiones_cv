import docx2txt
import glob

directory = glob.glob('CurriculumActualizadoSpain1.docx')

from keybert import KeyBERT

kw_model = KeyBERT(model='paraphrase-multilingual-mpnet-base-v2')

########Convertir  docx a txt
def convertir_txt(directory):
    for file_name in directory:
    
        with open(file_name, 'rb') as infile:
            outfile = open(file_name[:-5]+'.txt', 'w', encoding='utf-8')
            doc = docx2txt.process(infile)
    
            outfile.write(doc)
    
        outfile.close()
        infile.close()

    print("=========")
    print("All done!")
    
convertir_txt(directory)

f = open("CurriculumActualizadoSpain1.txt")

aaaa = f.readlines()
        
bb = ''.join(aaaa)

from keybert import KeyBERT

kw_model = KeyBERT(model='paraphrase-multilingual-mpnet-base-v2')

#title = "VECTORIZATION OF TEXT USING DATA MINING METHODS"

#text = "Profesional con 12 años de experiencia en empresas de aplicaciones informáticas. Dominio avanzado en programación SQL, manipulación de los diferentes gestores de base de datos (PostgreSQL, MySQL, Oracle y SQLServer), Réplica de base de datos, Migración de base de datos (Extracción, Carga y Transformación(ETL)). Desarrollador Senior en Python, Experta en Ciencia de Datos, Inteligencia de Negocio, Análisis de Datos. Experiencia como Líder de Proyecto, Desarrolladora, Arquitecta de Datos y Arquitecta de Software. Automotivada, comprometida, buenas habilidades tanto de aprendizaje como de comunicación, buen desempeño bajo presión y ambientes dinámicos."

full_text = bb

#print("The whole text to be usedn",full_text)

keywords = kw_model.extract_keywords(full_text, 

                                     keyphrase_ngram_range=(1, 5), 

                                     stop_words='english', 

                                     highlight=True,

                                     top_n=10)

keywords_list= list(dict(keywords).keys())

print(keywords_list)



#print(f.readlines())
