# -*- coding: utf-8 -*-
"""
Created on Wed Jul  5 21:39:13 2023

@author: Dell
"""

from keybert import KeyBERT

kw_model = KeyBERT(model='paraphrase-multilingual-mpnet-base-v2')

title = "VECTORIZATION OF TEXT USING DATA MINING METHODS"

text = "Profesional con 12 años de experiencia en empresas de aplicaciones informáticas. Dominio avanzado en programación SQL, manipulación de los diferentes gestores de base de datos (PostgreSQL, MySQL, Oracle y SQLServer), Réplica de base de datos, Migración de base de datos (Extracción, Carga y Transformación(ETL)). Desarrollador Senior en Python, Experta en Ciencia de Datos, Inteligencia de Negocio, Análisis de Datos. Experiencia como Líder de Proyecto, Desarrolladora, Arquitecta de Datos y Arquitecta de Software. Automotivada, comprometida, buenas habilidades tanto de aprendizaje como de comunicación, buen desempeño bajo presión y ambientes dinámicos."

full_text = text 

#print("The whole text to be usedn",full_text)

keywords = kw_model.extract_keywords(full_text, 

                                     keyphrase_ngram_range=(1, 3), 

                                     stop_words='english', 

                                     highlight=False,

                                     top_n=10)

keywords_list= list(dict(keywords).keys())

print(keywords_list)