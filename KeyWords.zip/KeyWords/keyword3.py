# -*- coding: utf-8 -*-
"""
Created on Wed Jul  5 22:12:11 2023

@author: Dell
"""

a= """
Yanet Cesaire



Msc, Ing. en Ciencias Infor-máticas
g 28 de agosto de 1986

Ó +5353502571

[ 86yanetc@gmail.com https://www.linkedin.com/in/yanet-cesaire-125661200/

Idiomas



Español
?????
Inglés


?????


Resumen


  Profesional con 12 años de experiencia en empresas de aplicaciones informáticas. Dominio avanzado en programación SQL, manipulación de los diferentes gestores de base de datos (PostgreSQL, MySQL, Oracle y SQLServer), Réplica de base de datos, Migración de base de datos (Extracción, Carga y Transformación(ETL)). Desarrollador Senior en Python, Experta en Ciencia de Datos, Inteligencia de Negocio, Análisis de Datos. Experiencia como Líder de Proyecto, Desarrolladora, Arquitecta de Datos y Arquitecta de Software. Automotivada, comprometida, buenas habilidades tanto de aprendizaje como de comunicación, buen desempeño bajo presión y ambientes dinámicos.

Educación

2012 - 2014
Máster en Informática
Universidad de las Ciencias Informáticas, Cuba

Aplicada

- Tesis: Algoritmos basados en la Transformada Wavelet con selección adaptativa del umbral para la reducción de ruido en sismogramas.

2005 - 2010
Ingeniera en Ciencias
Universidad de las Ciencias Informáticas, Cuba

Informática

- Tesis: Algoritmos para detectar bordes en las imágenes.

Experiencia laboral


2021/12 -	Arquitecta de base de datos	Axcelere, Argentina
Actualidad	- Upgrade de base de datos de odoo 13 a 15, usando servicio odoo.

Migración de datos de diversas fuentes de datos.Extracción, Carga y Transformación (ETL) usando herramienta Pentaho Data Integration (PDI). Realizar consultas SQL complejas.

Habilidades


9 Comunicación

• Liderazgo Trabajo en equipo

2021/01 -

2021/11


2019 - 2021

Arquitecta de base de datos	Oxe360, Perú

- Upgrade de base de datos de odoo 11 a 13 usando servicio odoo. Migración de base de datos. Realizar consultas complejas.

Arquitecta de Software y

Empresa de Aplicaciones Informáticas, Cuba
Desarrolladora Senior
- Desarrollo de microservicios, empleando graphene con GraphQL,FastApi en Python .

Positividad

x Enfocado a objetivos

Herramientas

PostgreSQL
Jupyter
Spyder
MySQL
RapidMiner
MicroStrategy
Pentaho Data Integration
VM Cloudera
Odoo 10 hasta 15
Intereses

Base de Datos

Desarrollador en Inteligencia de Ne-gocio
Ciencia de Datos

Desarrollo de software

2019 - 2021

2019 -

actualidad
- 
Desarrollo de un módulo para integrar herramientas a partir del consumo de APIS (GITLAB,MANTIS,JENKINS,SONARQVE).

- Desarrollo de prototipo en Python para el trabajo con cola de mensajería(RABBITMQ).

Senior en Ciencia de Datos y

Empresa de Aplicaciones Informática, Cuba
Analista Senior en Datos
- Uso de las libreria Numpy, Matplotlib, Pandas, Scipy, Searborn.

- Implementación usando Python para limpiar, transformar y visualizar los datos.
- Análisis estadísticos usando los diferentes test estadísticos.

- Emplear algoritmos de machine learning (Regression Lineal, Classifica-tion, Arboles de Decisiones, K-Means Clustering, Random Forest, entre otros).

- SQL con Hadoop y Spark para Ciencias de Datos.

- Trabajo con base de datos No SQL (Cassandra, MongoDB, Redis)

Senior DataWarehouse e Inteligencia de Negocio	Trabajo Remoto, Cuba

- Diseño de DataWarehouse, empleando lenguaje SQL avanzado (fun-ciones analíticas, funciones de agregación, entre otras).

- Empleo de herramienta Pentaho Data Integration para La carga, ex-tración y transformación (PDI).

- Empleo de la herramienta RapidMiner y MicroStrategy para Inteligencia de Negocio.
- Diseño de Dashboard usando herramienta MicroStrategy.

Jefa de Proyecto y Desarrolladora

2018-2019	Centro de Desarrollo de Software, Cuba
Senior en Python

- Implementar sistema Estadísticos, para reportar informaciones es-tadísticas.

- Implementar sistema para la planificación del presupuesto.

- Desarrollo de componente para reutilizar en los diferente proyectos (marco de trabajo odoo 10, 11 y 12).

Arquitecta de Base de Datos y

2012-2018	Centro de Desarrollo de Software, Cuba
Desarrolladora Senior en Python

- Implementación de módulo en la suite de OpenERP.

- Desarrollo en Python de una herramienta de réplica en OpenERP basado en la herramienta de réplica SymmetriDS.
- Diseño de esquema de replicación con la herramienta SymmetricDS con el propósito de replicar todas las multas impuestas en Cuba.
- Diseño de esquema de replicación con la herramienta SymmetricDS para la Empresa Hidráulica de Cuba, mantener a los altos mandos actu-alizados sobre la situación hidráulica del país.

- Diseño de base de datos en diferentes herramientas de modelado.

Referencias


Ing.Yarisleidis
Jefa de Centro de Desarrollo
Cuba
Fernandez Rivera
+58326367
yarifr85@gmail.com
Dr.Rafael Arturo Trujillo  Especialista Principal en SERCONI
Cuba
Codorniú
+5359983476
rtrujillo@uo.edu.cu
"""

print(a)


from keybert import KeyBERT

kw_model = KeyBERT(model='paraphrase-multilingual-mpnet-base-v2')

title = "VECTORIZATION OF TEXT USING DATA MINING METHODS"

text = "Profesional con 12 años de experiencia en empresas de aplicaciones informáticas. Dominio avanzado en programación SQL, manipulación de los diferentes gestores de base de datos (PostgreSQL, MySQL, Oracle y SQLServer), Réplica de base de datos, Migración de base de datos (Extracción, Carga y Transformación(ETL)). Desarrollador Senior en Python, Experta en Ciencia de Datos, Inteligencia de Negocio, Análisis de Datos. Experiencia como Líder de Proyecto, Desarrolladora, Arquitecta de Datos y Arquitecta de Software. Automotivada, comprometida, buenas habilidades tanto de aprendizaje como de comunicación, buen desempeño bajo presión y ambientes dinámicos."

full_text = a 

#print("The whole text to be usedn",full_text)


kw_model = KeyBERT()

keywords = kw_model.extract_keywords(full_text)

print(kw_model.extract_keywords(full_text, keyphrase_ngram_range=(1, 1), stop_words=None))